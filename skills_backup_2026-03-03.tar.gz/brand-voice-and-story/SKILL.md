---
name: brand-voice-and-story
description: Define brand voice + founder story arc + reusable self-intro scripts for a healing personal brand (WeChat / X / community).
---

## What this skill does
Builds a coherent **brand voice + founder story** for the healing track (职场女性身心灵疗愈), and outputs reusable copy for:
- 公众号简介/置顶
- X bio/置顶
- 社群置顶自我介绍
- 私信自我介绍（不油）

Goal: make you recognizable, trustworthy, and consistent.

---

## Inputs
1) 你的人设关键词（3个）：例如 温柔/直接/理性/幽默
2) 你最想服务的人群一句话
3) 你的关键经历（3段）：
   - 以前：我经历了什么困境/卡点
   - 转折：我遇到什么方法/老师/事件
   - 现在：我如何稳定下来/得到结果
4) 你的方法论（1句话）：你解决问题的方式
5) 你的边界（你不做什么）

---

## Output 1 — Brand voice rules (3–5条)
写法：**我会… / 我不会…**
示例：
- 我会用温柔但不含糊的语言；我不会用恐吓式焦虑营销。
- 我会提供可执行的 10–15 分钟练习；我不会承诺治愈。
- 我会尊重隐私与边界；我不会公开未经授权的案例。

---

## Output 2 — Founder story arc (Why me / Why now)
模板（200–300字）：
- 我是谁（1句）
- 我曾经卡在哪里（2–3句）
- 我怎么转折（2–3句）
- 我现在在做什么（1–2句）
- 我能帮你什么（1句）

---

## Output 3 — Reusable intros (copy-paste)
### A) 公众号简介（60–100字）
结构：人群→问题→结果→方法→边界

### B) X Bio（<=160字符，中英可选）
结构：身份 + 方向 + 证明 + CTA

### C) 社群置顶自我介绍（120–200字）
结构：欢迎→我是谁→群里能得到什么→群规一句话→互动引导

### D) 私信自我介绍（不油版，50–80字）
结构：共鸣→两问诊断→小练习

---

## Output 4 — Content POV (你的核心观点库)
给 5 条“可反复引用”的品牌观点：
1) 
2) 
3) 
4) 
5) 

---

## Notes
- 语言要真实，不要像营销号。
- 疗愈方向要特别注意：不夸大，不承诺治疗效果。

