---
name: ip-positioning
description: Generate a crisp personal IP positioning statement and content pillars for a solo founder.
homepage: https://docs.openclaw.ai
---

## What this skill does
Takes your background + target audience + niche and produces:
- A one-sentence positioning statement
- A 3-part offer hypothesis (people/problem/promise)
- 3–5 content pillars (公众号 / X 可用)
- A 2-week posting plan skeleton

## Inputs to ask for
- 你是谁（经历/证据）
- 你服务谁（具体人群）
- 你解决什么（核心痛点）
- 你交付什么结果（可量化）
- 你有什么差异化（方法/资源/故事）

## Output template
**定位一句话**：我帮助【人群】在【场景】解决【问题】，通过【方法】实现【结果】。

**Offer 假设**：
- 人群：
- 问题：
- 结果：

**内容支柱（3–5）**：
1) 
2) 
3) 

**14 天选题骨架（可循环）**：
- D1：你的故事 + why now
- D2：一个常见误区
- D3：一个可执行小步骤
- D4：案例/拆解
- D5：工具/清单
- ...（循环：误区→方法→案例→工具→问答）

## Notes
- 单条输出务必短、可复用、可复制到 flomo。
- 若用户有多个方向（如：身心灵疗愈 + 跨境电商），默认先拆成两条定位，不强行融合。

