---
name: x-thread-to-wechat-article
description: Convert an X thread into a WeChat Official Account article outline + draft with CTA and sections.
homepage: https://docs.openclaw.ai
---

## What this skill does
Takes:
- X thread text (a list of tweets or a long thread)
- Target audience (疗愈 / 跨境电商)
- Your offer / CTA
Outputs:
- A WeChat Official Account longform structure
- Title candidates (3–5)
- Section headings + key bullets
- A first-draft article (800–1500 words) in Chinese

---

## Inputs
1) **X thread 原文**（直接粘贴）
2) 方向：#疗愈 or #跨境电商
3) 受众一句话：例如「一线城市30岁+职场女性」「做Shopee/Lazada的独立卖家」
4) 你的 CTA：关注 / 回复关键词 / 私信 / 入群 / 预约咨询

---

## Conversion rules（从 X → 公众号）
### 1) 标题：反常识 + 人群 + 结果
- 公众号标题更“结果导向”，X 更“观点导向”。

标题模板：
- 「别再用【常见做法】了：真正让【人群】在【场景】变好的，是这 3 件事」
- 「我用【方法】帮【人群】解决【问题】：从【糟糕状态】到【理想状态】」

### 2) 开头 150 字：立刻给“共鸣 + 承诺”
- 你在讲谁的痛？
- 这篇能给她/他什么？

### 3) 正文结构（固定骨架）
1. 背景（为什么现在谈）
2. 误区（你过去怎么想错了/行业怎么误导）
3. 方法（3–5 点，每点：一句结论 + 解释 + 例子 + 1 个小练习）
4. 案例/对照（前后变化）
5. 清单总结（可截图收藏）
6. CTA（下一步怎么做）

### 4) 段落节奏
- 每段 2–4 句，长文也要“短段落”。
- 关键句加粗。

### 5) CTA 设计（不推销也能转化）
- 低门槛：回复关键词领取模板/清单
- 中门槛：入群
- 高门槛：预约咨询

---

## Output template
**标题候选（3–5）**：
1) 
2) 

**文章结构**：
- 开头：
- 误区：
- 方法 1/2/3：
- 案例：
- 清单总结：
- CTA：

**公众号草稿正文（800–1500字）**：
（输出全文）

---

## Notes
- 若 X thread 是英文：先翻译再改写。
- 若 thread 太长：先压缩成 5 条核心点，再扩写。
- 公众号不追求“信息量最大”，追求“读完能行动 + 愿意关注”。

