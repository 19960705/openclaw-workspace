---
name: action-checklist-generator
description: Generate a '迷茫→行动' 10-minute checklist + keyword auto-reply copy for WeChat/X/community.
---

## What this skill does
Creates a small, screenshot-friendly checklist that turns a big worry into a first 10-minute action.
Outputs:
- 1-page checklist (for flomo/WeChat)
- Auto-reply copy using keyword 【行动】
- A 7-day light action plan (optional)

---

## The 10-minute "迷茫→行动" checklist
**Step 0（1分钟）：命名你的担忧**
- 我担心：__________________

**Step 1（2分钟）：把它从“情绪”变成“问题”**
- 这件事最糟的后果是：__________________
- 它发生的频率（每周/每月）：__________________

**Step 2（3分钟）：拆成可控的小动作**
从下面选一个（只选一个）：
- 【证据卡】写下 3 个你做成过的结果（哪怕很小）
- 【主题卡】写下 3 个你愿意投入 2 年的主题
- 【技能卡】列 1 个你工作中可被 AI 打底的任务（明天就试一次）

**Step 3（3分钟）：定义验收标准**
- 我做完的标准是：__________________（例如：写完100字/列出3条/发出1条消息）

**Step 4（1分钟）：安排时间**
- 我什么时候做：__________________（具体到“今晚21:30”）

---

## Keyword auto-reply copy（公众号/社群/私信）
> 你回复【行动】，我会把这份《迷茫→行动拆解清单》发你。
> 你也可以把你的担忧发我一句话，我帮你拆成“今天就能做”的第一步。

---

## Notes
- Keep it gentle and practical (姐姐陪你拆解风格).
- Avoid medical/therapy claims.

