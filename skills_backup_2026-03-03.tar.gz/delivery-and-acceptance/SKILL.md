---
name: delivery-and-acceptance
description: Delivery checklist, daily check-in template, acceptance criteria, and retrospective for a 7-day healing program.
---

## What this skill does
For a **7-day healing / emotional regulation / boundary training** program, outputs:
- Delivery checklist (what you must deliver each day)
- Daily check-in (打卡) format for clients
- Acceptance criteria (验收标准) that are behavior/process-based
- A simple retrospective template (复盘)

Goal: make delivery repeatable and reduce churn/refund risk.

---

## Core delivery rules
- Every day must have: 1 micro-exercise (≤15 min) + 1 reflection question + 1 feedback loop
- Client only needs to do ONE thing per day
- Acceptance is based on **execution**, not "cured" outcomes
- Always include safety boundary: not medical treatment

---

## 7-day delivery plan (template)
### Day 0 (after payment)
- Send: Welcome message + boundaries + how check-in works
- Collect: baseline score (0–10), sleep, stress trigger list

### Day 1 — Baseline & trigger map
- Deliver: Trigger mapping worksheet
- Exercise: 10 min "name it to tame it" (label emotions)
- Check-in: trigger + body sensation + 0–10 score

### Day 2 — Nervous system downshift
- Deliver: 2 breathing options + one grounding routine
- Exercise: 10 min breathing + 2 min body scan
- Check-in: before/after score

### Day 3 — Thought loop interrupt
- Deliver: 3-step cognitive defusion card
- Exercise: write 1 recurring thought and defuse
- Check-in: which step worked

### Day 4 — Boundary script
- Deliver: 3 refusal scripts (soft/firm/pro)
- Exercise: rewrite one real message
- Check-in: send screenshot (optional) + feelings

### Day 5 — Energy routine
- Deliver: 15 min routine (sleep/light/walk)
- Exercise: choose 1 habit and do once
- Check-in: what made it easy/hard

### Day 6 — Relapse plan
- Deliver: "bad day" emergency plan card
- Exercise: write your top 3 relapse signs + actions
- Check-in: commit to 1 action

### Day 7 — Review & next step
- Deliver: before/after comparison + personalized notes
- Exercise: write 3 learnings + 1 next week plan
- Check-in: final score + next step choice

---

## Client daily check-in template (copy-paste)
**Day X 打卡**
- 今日练习完成了吗？（是/否）
- 练习前分数（0–10）：
- 练习后分数（0–10）：
- 今天的触发点：
- 身体感受：
- 我学到/发现了什么：
- 明天我愿意做的一个小动作：

---

## Acceptance criteria (验收标准)
- 7 天内完成 ≥5 天练习
- 能说清楚自己的 Top 3 触发点
- 有一张可执行的“坏日子应急卡”
- 形成一个可重复的 10–15 分钟稳定动作

---

## Retrospective template (for you)
- 本期最常见触发点 Top3：
- 最有效练习 Top2：
- 最常见阻碍 Top2：
- 下一期要改的 1 件事：
- 可公开匿名案例 1 条：

---

## Notes
- If user asks for medical claims, explicitly refuse and redirect to professional help.
- Keep artifacts screenshot-friendly for WeChat.

